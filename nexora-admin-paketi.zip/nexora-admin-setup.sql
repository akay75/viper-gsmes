-- NEXORA ADMIN ACCESS
-- 1) Önce ana siteden kendi hesabını oluştur ve e-posta doğrulamasını tamamla.
-- 2) Supabase Dashboard > SQL Editor ekranında bu dosyayı çalıştır.
-- 3) Aşağıdaki USER_UUID değerini Authentication > Users bölümündeki kendi kullanıcı UUID'n ile değiştir.
-- 4) Son SQL satırındaki yorumu kaldırıp sorguyu tekrar çalıştır.

create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

alter table public.admin_users enable row level security;

-- Kullanıcı yalnızca kendi admin kaydını okuyabilir.
drop policy if exists "Admins can read own admin record" on public.admin_users;
create policy "Admins can read own admin record"
on public.admin_users for select
to authenticated
using (auth.uid() = user_id);

-- Yetkilendirme işlemi yalnızca SQL Editor / güvenilir yönetici ortamından yapılır.
-- Tarayıcıdan admin kaydı ekleme, değiştirme veya silme politikası oluşturulmaz.

-- KENDİ UUID'Nİ YAZIP AŞAĞIDAKİ SATIRI ÇALIŞTIR:
-- insert into public.admin_users (user_id) values ('USER_UUID');
